Very old first and initial writing
